function submitForm(event) {
  event.preventDefault();
  const formMessage = document.getElementById('formMessage');
  formMessage.textContent = 'Thanks — your request is ready. Connect this form to Formspree, Netlify Forms, or your email service to receive submissions.';
  event.target.reset();
  return false;
}
