# P & J Transport LLC Website

This is a premium starter website for P & J Transport LLC.

## Files
- `index.html` — main website page
- `styles.css` — styling and layout
- `script.js` — simple form message

## Business details added
- Phone: 617-216-2942
- Email: Pjtranspollc@gmail.com

## How to use
1. Upload these files to your GitHub repository.
2. Turn on GitHub Pages or deploy with Netlify/Vercel.
3. Connect your domain.
4. Replace any text you want with your exact services, city/state, and company details.

## Good next upgrades
- Add real truck or logistics photos
- Add a quote form that sends to your email
- Add pages for Services, About, and Contact
- Add Google Maps and customer reviews
